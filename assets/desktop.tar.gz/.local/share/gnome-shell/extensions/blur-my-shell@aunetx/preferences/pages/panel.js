import Adw from 'gi://Adw';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';


export const Panel = GObject.registerClass({
    GTypeName: 'Panel',
    Template: GLib.uri_resolve_relative(import.meta.url, '../../ui/panel.ui', GLib.UriFlags.NONE),
    InternalChildren: [
        'blur',
        'pipeline_choose_row',
        'mode_static',
        'mode_dynamic',
        'corner_radius',
        'rounded_corners',
        'unblur_in_overview',
        'force_light_text',
        'override_background',
        'style_panel',
        'override_background_dynamically',
        'override_background_dynamically_mode_row',
        'override_background_dynamically_mode',
        'gradient_panel_row',
        'gradient_panel',
        'gradient_panel_mode_row',
        'gradient_panel_mode',
        'hidetopbar_compatibility',
        'dtp_blur_original_panel'
    ],
}, class Panel extends Adw.PreferencesPage {
    constructor(preferences, pipelines_manager, pipelines_page) {
        super({});

        this.preferences = preferences;
        this.pipelines_manager = pipelines_manager;
        this.pipelines_page = pipelines_page;

        this.preferences.panel.settings.bind(
            'blur', this._blur, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        this._pipeline_choose_row.initialize(
            this.preferences.panel, this.pipelines_manager, this.pipelines_page
        );

        this.change_blur_mode(this.preferences.panel.STATIC_BLUR, true);

        this._mode_static.connect('toggled',
            () => this.preferences.panel.STATIC_BLUR = this._mode_static.active
        );
        this.preferences.panel.STATIC_BLUR_changed(
            () => this.change_blur_mode(this.preferences.panel.STATIC_BLUR, false)
        );

        this.preferences.panel.settings.bind(
            'corner-radius', this._corner_radius, 'value',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'rounded-corners', this._rounded_corners, 'selected',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'unblur-in-overview', this._unblur_in_overview, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'force-light-text', this._force_light_text, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'override-background',
            this._override_background, 'enable-expansion',
            Gio.SettingsBindFlags.DEFAULT | Gio.SettingsBindFlags.NO_SENSITIVITY
        );
        this.preferences.panel.settings.bind(
            'style-panel', this._style_panel, 'selected',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'override-background-dynamically',
            this._override_background_dynamically, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'override-background-dynamically-mode',
            this._override_background_dynamically_mode, 'selected',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'gradient-panel', this._gradient_panel, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.settings.bind(
            'gradient-panel-mode', this._gradient_panel_mode, 'selected',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.panel.OVERRIDE_BACKGROUND_DYNAMICALLY_changed(
            () => this.proximity_option_changed()
        );
        this.preferences.panel.OVERRIDE_BACKGROUND_DYNAMICALLY_MODE_changed(
            () => this.proximity_option_changed()
        );
        this.preferences.panel.GRADIENT_PANEL_changed(
            () => this.proximity_option_changed()
        );
        this.preferences.hidetopbar.settings.bind(
            'compatibility', this._hidetopbar_compatibility, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        this.preferences.dash_to_panel.settings.bind(
            'blur-original-panel', this._dtp_blur_original_panel, 'active',
            Gio.SettingsBindFlags.DEFAULT
        );
    }

    proximity_option_changed() {
        const panel = this.preferences.panel;
        const dynamic = panel.OVERRIDE_BACKGROUND_DYNAMICALLY;
        const blur_on_proximity = dynamic && panel.OVERRIDE_BACKGROUND_DYNAMICALLY_MODE === 0;
        this._override_background_dynamically_mode_row.set_visible(dynamic);
        this._gradient_panel_row.set_visible(blur_on_proximity);
        this._gradient_panel_mode_row.set_visible(blur_on_proximity && panel.GRADIENT_PANEL);
    }

    change_blur_mode(is_static_blur, first_run) {
        this._mode_static.set_active(is_static_blur);
        if (first_run)
            this._mode_dynamic.set_active(!is_static_blur);

        this.proximity_option_changed();
    }
});
