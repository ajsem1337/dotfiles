
const getWindowById = (winid) => {
  if (!winid || winid <= 0) return null;

  try {
    const windowActors = global.get_window_actors();
    const actor = windowActors.find((w) => {
      try {
        return w.meta_window && w.meta_window.get_id() === winid;
      } catch {
        return false;
      }
    });
    return actor?.meta_window ?? null;
  } catch (_error) {
    return null;
  }
};

const getCurrentWorkspace = () => {
  const workspaceManager = global.workspace_manager;
  return workspaceManager.get_active_workspace();
};

const getCurrentMonitor = () => {
  return global.display.get_current_monitor();
};

const getCurrentTime = () => {
  return global.get_current_time();
};

const getFocusedWindow = () => {
  const windowActors = global.get_window_actors();
  const actor = windowActors.find((w) => w.meta_window?.has_focus());
  return actor?.meta_window ?? null;
};

const getFocusedWindowApp = () => {
  const focusedWindow = getFocusedWindow();
  if (focusedWindow) {
    const wmClass = focusedWindow.get_wm_class();
    const title = focusedWindow.get_title();

    return wmClass || title || "unknown";
  }
  return "gnome-shell";
};


const isLegacyWindow = (win) => typeof win.is_maximized !== "function";

const MAXIMIZE_BOTH = 3;

const isMaximized = (win) => isLegacyWindow(win) ? win.get_maximized() : win.is_maximized();

const isFullyMaximized = (win) => {
  const state = isMaximized(win);
  return state === true || state === MAXIMIZE_BOTH;
};

const getWindowState = (win) => {
  if (win.is_fullscreen()) return "fullscreen";
  if (win.minimized) return "minimized";
  if (isFullyMaximized(win)) return "maximized";
  return "normal";
};

const maximize = (win) => {
  if (isLegacyWindow(win)) win.maximize(MAXIMIZE_BOTH);
  else win.maximize();
};

const unmaximize = (win) => {
  if (isLegacyWindow(win)) win.unmaximize(MAXIMIZE_BOTH);
  else win.unmaximize();
};

const isTargetWindow = (window, appClass = "vicinae") => {
  if (!window) return false;

  const wmClass = window.get_wm_class();
  if (!wmClass) return false;

  const lowerWmClass = wmClass.toLowerCase();
  const lowerAppClass = appClass.toLowerCase();

  if (!lowerWmClass.includes(lowerAppClass) && !lowerAppClass.includes(lowerWmClass)) {
    return false;
  }

  return !window.allows_resize();
};

export {
  getCurrentMonitor,
  getCurrentTime,
  getCurrentWorkspace,
  getFocusedWindow,
  getFocusedWindowApp,
  getWindowById,
  getWindowState,
  isFullyMaximized,
  isMaximized,
  isTargetWindow,
  maximize,
  unmaximize
};
