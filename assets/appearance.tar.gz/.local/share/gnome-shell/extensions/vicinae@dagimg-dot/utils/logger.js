
const PROJECT_NAME = "Vicinae";

const LOGGING_LEVELS = ["error", "warn", "info", "debug"];

const DEFAULT_LOG_LEVEL = "info";

const getVerbosity = (level) => {
  const idx = LOGGING_LEVELS.indexOf(
    level.toLowerCase()
  );
  return idx >= 0 ? idx : LOGGING_LEVELS.indexOf(DEFAULT_LOG_LEVEL);
};

let currentVerbosity = getVerbosity(DEFAULT_LOG_LEVEL);

const initializeLogger = (settings) => {
  const levelString = settings.get_string("logging-level");
  currentVerbosity = getVerbosity(levelString);

  settings.connectObject(
    "changed::logging-level",
    () => {
      const newLevelString = settings.get_string("logging-level");
      currentVerbosity = getVerbosity(newLevelString);
      info(`Log level changed to: ${newLevelString}`);
    },
    logger
  );

  info(`Logger initialized with level: ${levelString}`);
};

const deinitializeLogger = (settings) => {
  settings.disconnectObject(logger);
};

const isErrorLike = (data) => data instanceof Error || typeof data === "object" && data !== null && "message" in data && typeof data.message === "string";

const write = (prefix, message, data) => {
  const lines = [`${prefix}: ${message}`];
  if (data !== void 0 && data !== null) {
    if (isErrorLike(data)) {
      lines.push(`${prefix}:   ${String(data)}`);
      if (typeof data.stack === "string" && data.stack) {
        lines.push(`${prefix}:   ${data.stack.trimEnd()}`);
      }
    } else if (typeof data === "object") {
      Object.entries(data).forEach(([key, value]) => {
        lines.push(`${prefix}:   ${key}: ${value}`);
      });
    } else {
      lines.push(`${prefix}: ${data}`);
    }
  }
  console.log(lines.join("\n"));
};

const log = (level, message, data) => {
  if (LOGGING_LEVELS.indexOf(level) > currentVerbosity) return;

  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  const prefix = `[${PROJECT_NAME}] ${timestamp} ${level.toUpperCase()}`;
  write(prefix, message, data);
};

const debug = (message, data) => {
  log("debug", message, data);
};

const info = (message, data) => {
  log("info", message, data);
};

const warn = (message, data) => {
  log("warn", message, data);
};

const error = (message, err) => {
  log("error", message, err);
};

const logger = {
  debug,
  info,
  warn,
  error
};

export {
  DEFAULT_LOG_LEVEL,
  LOGGING_LEVELS,
  deinitializeLogger,
  getVerbosity,
  initializeLogger,
  logger
};
