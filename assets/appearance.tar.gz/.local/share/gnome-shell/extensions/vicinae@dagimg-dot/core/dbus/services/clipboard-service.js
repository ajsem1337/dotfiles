import GLib from "gi://GLib";
import {
  CLIPBOARD_CONFIG,
  calculateClipboardMetadata
} from "../../../utils/clipboard-utils.js";
import { logger } from "../../../utils/logger.js";
import { createHandlers } from "../../clipboard/handlers/index.js";

class ClipboardService {
  clipboardManager;
  contentHandlers;
  dbusObject = null;
  clipboardListener = null;
  isListening = false;

  constructor(clipboardManager) {
    this.clipboardManager = clipboardManager;
    this.contentHandlers = createHandlers();
    logger.info("ClipboardService initialized with binary-only protocol");
  }

  // Method to set the D-Bus exported object (called by DBusManager)
  setDBusObject(dbusObject) {
    this.dbusObject = dbusObject;

    const listener = this.getOrCreateClipboardListener();
    this.clipboardManager.onClipboardChange(listener);
    this.isListening = true;

    logger.info("\u{1F4E1} Binary-only D-Bus clipboard listener activated");
  }

  getOrCreateClipboardListener() {
    if (this.clipboardListener) {
      return this.clipboardListener;
    }

    const signalPayloadContext = {
      getBinaryData: (marker) => this.clipboardManager.getBinaryData(marker)
    };

    this.clipboardListener = (event) => {
      let payload = null;

      try {
        if (!event.content || event.content.length === 0) {
          logger.debug("Skipping empty clipboard content");
          return;
        }

        const metadata = calculateClipboardMetadata(event);

        const handler = this.contentHandlers.find(
          (h) => h.contentType === event.contentType
        );

        payload = handler?.toSignalPayload(event, signalPayloadContext) ?? null;

        if (!payload) {
          logger.warn(
            `No handler produced payload for content: ${event.content.substring(0, 50)}...`
          );
          return;
        }

        if (payload.content.length > CLIPBOARD_CONFIG.MAX_CLIPBOARD_SIZE) {
          logger.warn(
            `Clipboard data too large: ${payload.content.length} bytes, skipping`
          );
          return;
        }

        logger.debug(
          `Processing clipboard: ${payload.mimeType}, ${payload.content.length} bytes from ${metadata.sourceApp}`
        );

        this.emitBinarySignal(payload.content, {
          mimeType: payload.mimeType,
          sourceApp: metadata.sourceApp
        });
      } catch (signalError) {
        logger.error("Error processing clipboard event", {
          error: signalError,
          errorType: typeof signalError,
          errorMessage: signalError instanceof Error ? signalError.message : String(signalError),
          stack: signalError instanceof Error ? signalError.stack : void 0
        });
      } finally {
        if (payload && !payload.mimeType.startsWith("text/")) {
          logger.debug(
            `ClipboardService: clearing binary store for marker "${event.content}"`
          );
          this.clipboardManager.clearBinaryDataStore(event.content);
          logger.debug("ClipboardService: binary marker cleared");
        }
      }
    };

    return this.clipboardListener;
  }

  emitBinarySignal(content, metadata) {
    try {
      logger.debug(
        `Emitting binary signal: ${metadata.mimeType}, ${content.length} bytes`
      );

      this.dbusObject?.emit_signal(
        "ClipboardChanged",
        GLib.Variant.new("(ayss)", [
          content,
          String(metadata.mimeType),
          String(metadata.sourceApp)
        ])
      );

      logger.info(
        `Binary signal emitted: ${metadata.mimeType}, ${content.length} bytes`
      );
    } catch (error) {
      logger.error("Failed to emit binary signal", error);
      throw error;
    }
  }

  // Method to start listening to clipboard changes
  ListenToClipboardChanges() {
    try {
      if (!this.isListening) {
        logger.debug("D-Bus: Starting clipboard listener...");
        const listener = this.getOrCreateClipboardListener();
        this.clipboardManager.onClipboardChange(listener);
        this.isListening = true;
        logger.info(
          "\u{1F4E1} Binary D-Bus clipboard listener activated via method call"
        );
      } else {
        logger.debug("D-Bus: Clipboard listener already active");
      }
    } catch (error) {
      logger.error("D-Bus: Error starting clipboard listener", error);
      throw error;
    }
  }

  // Method to manually trigger a clipboard change (for testing)
  TriggerClipboardChange(content, source = "user") {
    try {
      this.clipboardManager.triggerClipboardChange(
        content,
        source
      );
    } catch (error) {
      logger.error("D-Bus: Error triggering clipboard change", error);
      throw error;
    }
  }

  // Method to get current clipboard content
  GetCurrentContent() {
    try {
      return this.clipboardManager.getCurrentContent();
    } catch (error) {
      logger.error(
        "D-Bus: Error getting current clipboard content",
        error
      );
      throw error;
    }
  }

  // Method to set clipboard content
  SetContent(content) {
    try {
      this.clipboardManager.setContent(content);
    } catch (error) {
      logger.error("D-Bus: Error setting clipboard content", error);
      throw error;
    }
  }

  // Like SetContent, but the copy is never reported: Vicinae uses it for secrets it copies
  SetConcealedContent(content) {
    try {
      this.clipboardManager.setContent(content, true);
    } catch (error) {
      logger.error(
        "D-Bus: Error setting concealed clipboard content",
        error
      );
      throw error;
    }
  }

  SetConcealedContentBinary(content, mimeType) {
    try {
      this.clipboardManager.setContentBinary(content, mimeType, true);
    } catch (error) {
      logger.error(
        "D-Bus: Error setting concealed binary clipboard content",
        error
      );
      throw error;
    }
  }

  // Method to set binary clipboard content
  SetContentBinary(content, mimeType) {
    try {
      this.clipboardManager.setContentBinary(content, mimeType);
    } catch (error) {
      logger.error(
        "D-Bus: Error setting binary clipboard content",
        error
      );
      throw error;
    }
  }

  GetClipboardMimeTypes() {
    return [
      "text/plain",
      "text/uri-list",
      "text/html",
      "image/png",
      "image/jpeg",
      "image/gif",
      "image/webp"
    ];
  }

  // Method to stop listening to clipboard changes
  StopListening() {
    try {
      if (this.clipboardListener && this.isListening) {
        this.clipboardManager.removeClipboardListener(
          this.clipboardListener
        );
        this.isListening = false;
        logger.info("\u{1F515} Binary D-Bus clipboard listener deactivated");
      }
    } catch (error) {
      logger.error("Error stopping clipboard listener", error);
    }
  }

  // Cleanup method
  destroy() {
    this.StopListening();
    this.clipboardListener = null;
    this.dbusObject = null;
    logger.info("ClipboardService destroyed");
  }
}

export {
  ClipboardService
};
