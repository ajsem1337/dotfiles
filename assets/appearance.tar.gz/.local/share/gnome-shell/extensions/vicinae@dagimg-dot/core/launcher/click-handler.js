import Clutter from "gi://Clutter";
import { isTargetWindow } from "../../utils/window-utils.js";

class ClickHandler {

  constructor(appClass, onClickOutside) {
    this.appClass = appClass;
    this.onClickOutside = onClickOutside;
  }
  connected = false;

  enable() {
    if (this.connected) return;
    global.stage.connectObject(
      "captured-event",
      (_stage, event) => {
        if (event.type() === Clutter.EventType.BUTTON_PRESS)
          this.handleClick();
        return Clutter.EVENT_PROPAGATE;
      },
      this
    );
    this.connected = true;
  }

  disable() {
    if (!this.connected) return;
    global.stage.disconnectObject(this);
    this.connected = false;
  }

  handleClick() {
    const [x, y] = global.get_pointer();
    const clicked = global.get_window_actors().map((actor) => actor.meta_window).reverse().find((win) => {
      if (!win || win.minimized) return false;
      const rect = win.get_frame_rect();
      return x >= rect.x && x < rect.x + rect.width && y >= rect.y && y < rect.y + rect.height;
    });

    if (!isTargetWindow(clicked, this.appClass)) this.onClickOutside();
  }
}

export {
  ClickHandler
};
