import { logger } from "../../utils/logger.js";
import { isTargetWindow } from "../../utils/window-utils.js";
import { ClickHandler } from "./click-handler.js";
import { FocusTracker } from "./focus-tracker.js";
import { WindowTracker } from "./window-tracker.js";

class LauncherManager {

  constructor(appClass, onCloseRequested) {
    this.appClass = appClass;
    this.onCloseRequested = onCloseRequested;
    this.windowTracker = new WindowTracker(
      appClass,
      () => this.syncListeners()
    );
    this.focusTracker = new FocusTracker(() => this.handleFocusChange());
    this.clickHandler = new ClickHandler(
      appClass,
      () => this.requestClose()
    );
  }
  windowTracker;
  focusTracker;
  clickHandler;

  /** Trackers match windows by class, so a new class gets fresh ones that rescan. */
  setAppClass(appClass) {
    this.disable();
    this.appClass = appClass;
    this.windowTracker = new WindowTracker(
      appClass,
      () => this.syncListeners()
    );
    this.clickHandler = new ClickHandler(
      appClass,
      () => this.requestClose()
    );
    this.enable();
  }

  enable() {
    this.windowTracker.enable();
    this.syncListeners();
    logger.info("LauncherManager: enabled");
  }

  disable() {
    this.clickHandler.disable();
    this.focusTracker.disable();
    this.windowTracker.disable();
    logger.info("LauncherManager: disabled");
  }

  syncListeners() {
    if (this.windowTracker.size > 0) {
      this.focusTracker.enable();
      this.clickHandler.enable();
    } else {
      this.clickHandler.disable();
      this.focusTracker.disable();
    }
  }

  handleFocusChange() {
    if (!isTargetWindow(global.display.get_focus_window(), this.appClass))
      this.requestClose();
  }

  requestClose() {
    for (const windowId of this.windowTracker.windowIds) {
      logger.debug(`LauncherManager: requesting close of ${windowId}`);
      this.onCloseRequested(windowId);
    }
  }
}

export {
  LauncherManager
};
