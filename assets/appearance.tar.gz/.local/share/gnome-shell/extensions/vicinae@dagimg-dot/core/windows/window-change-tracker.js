import { logger } from "../../utils/logger.js";

const STATE_PROPERTIES = [
  "fullscreen",
  "minimized",
  "maximized-horizontally",
  "maximized-vertically"
];

class WindowChangeTracker {

  constructor(onSizeChanged, onStateChanged) {
    this.onSizeChanged = onSizeChanged;
    this.onStateChanged = onStateChanged;
  }
  trackedWindows = /* @__PURE__ */ new Set();

  connectToWindow(window) {
    const windowId = window.get_id();

    if (this.trackedWindows.has(windowId)) {
      logger.debug(
        `Window ${windowId} already has change connections, skipping`
      );
      return;
    }

    try {
      window.connectObject(
        "size-changed",
        () => {
          try {
            this.onSizeChanged(windowId);
          } catch (error) {
            logger.debug(
              `Error in size-changed callback for window ${windowId}: ${error}`
            );
          }
        },
        this
      );
      for (const property of STATE_PROPERTIES) {
        window.connectObject(
          `notify::${property}`,
          () => {
            try {
              this.onStateChanged(window);
            } catch (error) {
              logger.debug(
                `Error in state callback for window ${windowId}: ${error}`
              );
            }
          },
          this
        );
      }

      this.trackedWindows.add(windowId);
    } catch (error) {
      logger.debug(
        `Failed to connect change signals for window ${windowId}: ${error}`
      );
    }
  }

  connectToExistingWindows() {
    try {
      const windowActors = global.get_window_actors();

      for (const actor of windowActors) {
        if (actor.meta_window) {
          this.connectToWindow(actor.meta_window);
        }
      }
    } catch (error) {
      logger.debug(`Error connecting to existing windows: ${error}`);
    }
  }

  removeWindow(windowId) {
    this.trackedWindows.delete(windowId);
  }

  disconnectAll() {
    for (const actor of global.get_window_actors()) {
      actor.meta_window?.disconnectObject(this);
    }

    this.trackedWindows.clear();
  }
}

export {
  WindowChangeTracker
};
