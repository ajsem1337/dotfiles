import GLib from "gi://GLib";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
import { logger } from "../../../utils/logger.js";
import {
  getFocusedWindow,
  getWindowState,
  isTargetWindow
} from "../../../utils/window-utils.js";
import { WindowChangeTracker } from "../../windows/window-change-tracker.js";
import { VicinaeWindowManager } from "../../windows/window-manager.js";

class WindowsService {

  constructor(appClass) {
    this.appClass = appClass;
    this.windowManager = new VicinaeWindowManager(appClass);
    this.windowChangeTracker = new WindowChangeTracker(
      (windowId) => this.handleWindowSizeChanged(windowId),
      (window) => this.handleWindowStateChanged(window)
    );
  }
  windowManager;
  dbusObject = null;
  focusIdleSourceId = 0;
  overviewIdleId = 0;
  windowChangeTracker;
  /** Last state sent through statewindow, so repeated notifications send nothing new. */
  windowStates = /* @__PURE__ */ new Map();

  // Track previous focused window for paste-to-active-app functionality
  previousFocusedWindow = null;

  /** Follows a launcher-app-class change without re-exporting the service. */
  setAppClass(appClass) {
    this.appClass = appClass;
    this.windowManager.setAppClass(appClass);
  }

  // Method to set the D-Bus exported object (called by DBusManager)
  setDBusObject(dbusObject) {
    this.dbusObject = dbusObject;
    logger.debug("WindowsService: D-Bus object set for signal emission");

    this.setupWindowEventListeners();
  }

  setupWindowEventListeners() {
    logger.debug("WindowsService: Setting up GNOME window event listeners");

    global.window_manager.connectObject(
      "destroy",
      (_wm, actor) => {
        try {
          const metaWindow = actor.meta_window;
          if (!metaWindow) return;

          const windowId = metaWindow.get_id();

          logger.debug(
            `Window ${windowId} destroy signal triggered - emitting closewindow`
          );

          this.emitCloseWindow(windowId.toString());
          this.windowChangeTracker.removeWindow(windowId);
          this.windowStates.delete(windowId);
        } catch (error) {
          logger.debug(`Error handling window destroy: ${error}`);
        }
      },
      this
    );

    global.display.connectObject(
      "window-created",
      (_display, window) => {
        try {
          const windowInfo = this.getWindowInfo(window);
          this.emitOpenWindow(
            windowInfo.id.toString(),
            windowInfo.workspace.toString(),
            windowInfo.wm_class,
            windowInfo.title
          );

          this.windowChangeTracker.connectToWindow(window);
          this.hideOverviewWhenLauncherOpens(window);
        } catch (error) {
          logger.debug(
            `Error handling window opened event: ${error}`
          );
        }
      },
      "notify::focus-window",
      () => {
        try {
          if (this.focusIdleSourceId) {
            GLib.source_remove(this.focusIdleSourceId);
            this.focusIdleSourceId = 0;
          }

          this.focusIdleSourceId = GLib.idle_add(
            GLib.PRIORITY_DEFAULT_IDLE,
            () => {
              this.focusIdleSourceId = 0;
              const focusWindow = global.display.focus_window;
              if (focusWindow) {
                const currentWmClass = focusWindow.get_wm_class() || "";
                if (!isTargetWindow(focusWindow, this.appClass)) {
                  this.previousFocusedWindow = {
                    id: focusWindow.get_id(),
                    wmClass: currentWmClass
                  };
                }

                this.emitFocusWindow(
                  focusWindow.get_id().toString()
                );
              }
              return GLib.SOURCE_REMOVE;
            }
          );
        } catch (error) {
          logger.debug(`Error handling window focus event: ${error}`);
        }
      },
      this
    );

    this.windowChangeTracker.connectToExistingWindows();

    global.workspace_manager?.connectObject(
      "active-workspace-changed",
      () => {
        try {
          const activeWorkspace = global.workspace_manager?.get_active_workspace();
          if (activeWorkspace) {
            this.emitWorkspaceChanged(
              activeWorkspace.index().toString()
            );
          }
        } catch (error) {
          logger.debug(
            `Error handling workspace changed event: ${error}`
          );
        }
      },
      this
    );

    logger.debug(
      "WindowsService: GNOME window event listeners set up successfully"
    );
  }

  hideOverviewWhenLauncherOpens(window) {
    if (!Main.overview.visible) return;

    const wmClass = window.get_wm_class();
    if (!wmClass) {
      window.connectObject(
        "notify::wm-class",
        () => {
          window.disconnectObject(this);
          this.hideOverviewWhenLauncherOpens(window);
        },
        this
      );
      return;
    }

    if (isTargetWindow(window, this.appClass)) {
      if (this.overviewIdleId) {
        GLib.source_remove(this.overviewIdleId);
        this.overviewIdleId = 0;
      }

      this.overviewIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
        this.overviewIdleId = 0;
        Main.overview.hide();
        logger.debug(
          "WindowsService: Vicinae window opened, closing GNOME overview"
        );
        return GLib.SOURCE_REMOVE;
      });
    }
  }

  handleWindowStateChanged(window) {
    const windowId = window.get_id();
    const state = getWindowState(window);
    if (this.windowStates.get(windowId) === state) return;
    this.windowStates.set(windowId, state);
    this.emitStateWindow(windowId.toString(), state);
  }

  handleWindowSizeChanged(windowId) {
    try {
      const currentWindow = this.findWindowById(windowId);
      if (!currentWindow) return;
      const windowInfo = this.getWindowInfo(currentWindow);
      logger.debug(
        `Window ${windowId} size changed - emitting movewindow`
      );
      this.emitMoveWindow(
        windowInfo.id.toString(),
        windowInfo.x,
        windowInfo.y,
        windowInfo.width,
        windowInfo.height
      );
    } catch (error) {
      logger.debug(
        `Error handling size change for window ${windowId}: ${error}`
      );
    }
  }

  findWindowById(windowId) {
    try {
      const actors = global.get_window_actors();

      for (const actor of actors) {
        if (actor.meta_window?.get_id() === windowId) {
          return actor.meta_window;
        }
      }
    } catch {
    }
    return null;
  }

  getWindowInfo(window) {
    let x = 0, y = 0, width = 0, height = 0;

    try {
      if (typeof window.get_frame_rect === "function") {
        const frame = window.get_frame_rect();
        x = frame.x;
        y = frame.y;
        width = frame.width;
        height = frame.height;
      } else {
        logger.debug(
          `Window ${window.get_id()} does not have get_frame_rect method`
        );
      }
    } catch (error) {
      logger.debug(
        `Error getting frame rect for window ${window.get_id()}: ${error}`
      );
    }

    const workspace = window.get_workspace();
    return {
      id: window.get_id(),
      title: window.get_title(),
      wm_class: window.get_wm_class() || "",
      workspace: workspace ? workspace.index() : -1,
      x,
      y,
      width,
      height
    };
  }

  destroy() {
    logger.debug("WindowsService: Cleaning up window event listeners");
    if (this.focusIdleSourceId) {
      GLib.source_remove(this.focusIdleSourceId);
      this.focusIdleSourceId = 0;
    }
    if (this.overviewIdleId) {
      GLib.source_remove(this.overviewIdleId);
      this.overviewIdleId = 0;
    }
    global.window_manager.disconnectObject(this);
    global.display.disconnectObject(this);
    global.workspace_manager?.disconnectObject(this);
    this.windowChangeTracker.disconnectAll();
    this.windowStates.clear();
    this.dbusObject = null;

    logger.debug("WindowsService: Window event listeners cleaned up");
  }

  wrapDBusMethod(operation, fn, serialize) {
    try {
      const result = fn();
      return serialize ? serialize(result) : result;
    } catch (error) {
      logger.error(`D-Bus: Error ${operation}`, error);
      throw error;
    }
  }

  List() {
    return this.wrapDBusMethod(
      "listing windows",
      () => this.windowManager.list(),
      JSON.stringify
    );
  }

  Details(winid) {
    return this.wrapDBusMethod(
      "getting window details",
      () => this.windowManager.details(winid),
      JSON.stringify
    );
  }

  GetTitle(winid) {
    return this.wrapDBusMethod(
      "getting window title",
      () => this.windowManager.getTitle(winid)
    );
  }

  GetFrameRect(winid) {
    return this.wrapDBusMethod(
      "getting window frame rect",
      () => this.windowManager.getFrameRect(winid),
      JSON.stringify
    );
  }

  GetFrameBounds(winid) {
    return this.wrapDBusMethod(
      "getting window frame bounds",
      () => this.windowManager.getFrameBounds(winid),
      JSON.stringify
    );
  }

  MoveToWorkspace(winid, workspaceNum) {
    this.wrapDBusMethod(
      "moving window to workspace",
      () => this.windowManager.moveToWorkspace(winid, workspaceNum)
    );
  }

  MoveResize(winid, x, y, width, height) {
    this.wrapDBusMethod(
      "move resizing window",
      () => this.windowManager.moveResize(winid, x, y, width, height)
    );
  }

  Resize(winid, width, height) {
    this.wrapDBusMethod(
      "resizing window",
      () => this.windowManager.resize(winid, width, height)
    );
  }

  Move(winid, x, y) {
    this.wrapDBusMethod(
      "moving window",
      () => this.windowManager.move(winid, x, y)
    );
  }

  Maximize(winid) {
    this.wrapDBusMethod(
      "maximizing window",
      () => this.windowManager.maximize(winid)
    );
  }

  Minimize(winid) {
    this.wrapDBusMethod(
      "minimizing window",
      () => this.windowManager.minimize(winid)
    );
  }

  Unmaximize(winid) {
    this.wrapDBusMethod(
      "unmaximizing window",
      () => this.windowManager.unmaximize(winid)
    );
  }

  Unminimize(winid) {
    this.wrapDBusMethod(
      "unminimizing window",
      () => this.windowManager.unminimize(winid)
    );
  }

  Activate(winid) {
    this.wrapDBusMethod(
      "activating window",
      () => this.windowManager.activate(winid)
    );
  }

  Close(winid) {
    this.wrapDBusMethod(
      "closing window",
      () => this.windowManager.close(winid)
    );
  }

  ListWorkspaces() {
    return this.wrapDBusMethod(
      "listing workspaces",
      () => this.windowManager.listWorkspaces(),
      JSON.stringify
    );
  }

  GetActiveWorkspace() {
    return this.wrapDBusMethod(
      "getting active workspace",
      () => this.windowManager.getActiveWorkspace(),
      JSON.stringify
    );
  }

  GetWorkspaceWindows(workspaceIndex) {
    return this.wrapDBusMethod(
      "getting workspace windows",
      () => {
        const windows = this.windowManager.list();
        return windows.filter(
          (win) => win.workspace === workspaceIndex
        );
      },
      JSON.stringify
    );
  }

  GetFocusedWindowSync() {
    try {
      const focusedWindow = getFocusedWindow();
      if (!focusedWindow) {
        logger.debug("GetFocusedWindowSync: No focused window");
        return JSON.stringify(null);
      }

      const currentWmClass = focusedWindow.get_wm_class() || "";

      if (isTargetWindow(focusedWindow, this.appClass)) {
        if (this.previousFocusedWindow) {
          logger.debug(
            `GetFocusedWindowSync: Vicinae focused, returning previous window: ${this.previousFocusedWindow.wmClass}`
          );

          const windowDetails2 = this.windowManager.details(
            this.previousFocusedWindow.id
          );

          return JSON.stringify(windowDetails2);
        } else {
          logger.debug(
            "GetFocusedWindowSync: Vicinae focused but no previous window"
          );

          return JSON.stringify(null);
        }
      }

      logger.debug(
        `GetFocusedWindowSync: Returning current focused window: ${currentWmClass}`
      );

      const windowDetails = this.windowManager.details(
        focusedWindow.get_id()
      );

      return JSON.stringify(windowDetails);
    } catch (error) {
      logger.error("D-Bus: Error in GetFocusedWindowSync", error);
      return JSON.stringify(null);
    }
  }

  emitSignal(signalName, signature, args) {
    try {
      logger.debug(`Emitting ${signalName} signal...`);

      this.dbusObject?.emit_signal(
        signalName,
        GLib.Variant.new(signature, args)
      );
    } catch (signalError) {
      logger.error(`Error emitting ${signalName} signal`, signalError);
    }
  }

  emitOpenWindow(windowAddress, workspaceName, wmClass, title) {
    this.emitSignal("openwindow", "(ssss)", [
      String(windowAddress),
      String(workspaceName),
      String(wmClass),
      String(title)
    ]);
  }

  emitCloseWindow(windowAddress) {
    this.emitSignal("closewindow", "(s)", [String(windowAddress)]);
  }

  emitCloseRequested(windowAddress) {
    this.emitSignal("closerequested", "(s)", [String(windowAddress)]);
  }

  emitFocusWindow(windowAddress) {
    this.emitSignal("focuswindow", "(s)", [String(windowAddress)]);
  }

  emitMoveWindow(windowAddress, x, y, width, height) {
    this.emitSignal("movewindow", "(siiuu)", [
      String(windowAddress),
      x,
      y,
      width,
      height
    ]);
  }

  emitStateWindow(windowAddress, state) {
    this.emitSignal("statewindow", "(ss)", [
      String(windowAddress),
      String(state)
    ]);
  }

  emitWorkspaceChanged(workspaceId) {
    this.emitSignal("workspacechanged", "(s)", [String(workspaceId)]);
  }

  emitMonitorLayoutChanged() {
    this.emitSignal("monitorlayoutchanged", "()", []);
  }
}

export {
  WindowsService
};
