import Adw from "gi://Adw";
import Gdk from "gi://Gdk";
import GObject from "gi://GObject";
import Gtk from "gi://Gtk";
import { Icons } from "../lib/icons.js";

import { getTemplate } from "../utils/getTemplate.js";
import {
  makeBugReportUrl
} from "../utils/issue-report.js";


const CREDITS = [
  {
    title: "Dagim G. Astatkie",
    subtitle: "Original Author",
    github: "dagimg-dot"
  },
  {
    title: "Fernando Carletti",
    subtitle: "Contributor",
    github: "fernandocarletti"
  },
  {
    title: "Tommy Brunn",
    subtitle: "Contributor",
    github: "Nevon"
  },
  {
    title: "Yuriy Matskanyuk",
    subtitle: "Contributor",
    github: "SiriusCrain"
  },
  {
    title: "Noa Virellia",
    subtitle: "Contributor",
    github: "AsterisMono"
  },
  {
    title: "Andrei Zvonimir Crnkovi\u0107",
    subtitle: "Contributor",
    github: "andreicek"
  },
  {
    title: "John Niang",
    subtitle: "Contributor",
    github: "JohnNiang"
  },
  {
    title: "nothingrotf",
    subtitle: "Contributor",
    github: "nothingrotf"
  },
  {
    title: "abdssamie",
    subtitle: "Contributor",
    github: "Abdssamie"
  },
  {
    title: "Matheus In\xE1cio",
    subtitle: "Contributor",
    github: "matheus-inacio"
  },
  {
    title: "ilbebino08",
    subtitle: "Contributor",
    github: "ilbebino08"
  },
  {
    title: "hvnxdr",
    subtitle: "Contributor",
    github: "hvnxdr"
  },
  {
    title: "maxxxbond",
    subtitle: "Contributor",
    github: "maxxxbond"
  }
];

const LICENSE = `MIT License

Copyright (c) 2025 Dagim G. Astatkie

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.`;

const AboutPage = GObject.registerClass(
  {
    GTypeName: "VicinaeAboutPage",
    Template: getTemplate("AboutPage"),
    InternalChildren: [
      "extensionIcon",
      "extensionName",
      "extensionVersion",
      "linkWebsite",
      "linkIssues",
      "creditsRow",
      "legalRow",
      "extensionLicense"
    ]
  },
  class AboutPage2 extends Adw.PreferencesPage {

    setMetadata(metadata) {
      Icons.load(metadata.path);

      const vicinaeIcon = Icons.get("vicinae");

      this._extensionIcon.set_from_gicon(vicinaeIcon);

      this._extensionName.set_text(metadata.name);
      this._extensionVersion.set_text(
        `v${metadata["version-name"] || metadata.version}${""}`
      );

      if (metadata.url) {
        this._linkWebsite.connect("clicked", () => {
          Gtk.show_uri(null, metadata.url || "", Gdk.CURRENT_TIME);
        });
        this._linkIssues.connect("clicked", async () => {
          const issueUrl = await makeBugReportUrl(metadata);
          Gtk.show_uri(null, issueUrl, Gdk.CURRENT_TIME);
        });
      } else {
        this._linkWebsite.visible = false;
        this._linkIssues.visible = false;
      }

      this._extensionLicense.buffer.set_text(LICENSE, -1);

      this.renderCredits();
    }

    renderCredits() {
      const creditsExpander = this._creditsRow;

      CREDITS.forEach((credit) => {
        const creditRow = new Adw.ActionRow({
          title: credit.title,
          subtitle: credit.subtitle
        });

        if (credit.github) {
          const githubIcon = Icons.get("github");

          creditRow.add_suffix(
            new Gtk.Image({
              gicon: githubIcon,
              pixel_size: 16
            })
          );

          creditRow.set_activatable(true);
          creditRow.connect("activated", () => {
            this.openGitHubProfile(credit.github);
          });
        }

        creditsExpander.add_row(creditRow);
      });
    }

    openGitHubProfile(githubUsername) {
      if (!githubUsername) return;

      const githubUrl = `https://github.com/${githubUsername}`;
      try {
        Gtk.show_uri(null, githubUrl, Gdk.CURRENT_TIME);
      } catch (error) {
        console.error("Failed to open GitHub profile:", error);
      }
    }
  }
);

export {
  AboutPage,
  CREDITS
};
